<?php
//esta línea declara que este PHP utilizará sesiones
session_start();

include_once 'bd/Usuario.php';
include_once 'bd/UsuarioBD.php';

$nombreusuario = "";
$clave = "";
$mensaje = "";
if(isset($_POST['usuario']) && isset($_POST['clave'])){
    $nombreusuario = $_POST['usuario'];
    $clave = $_POST['clave'];
    
    $usuarioBD = new UsuarioBD();
    $usuario = $usuarioBD->login($nombreusuario, $clave);
    if($usuario == null){
        $mensaje = "ERROR: Usuario / Clave incorrectos.";
    }
    else{
        $_SESSION['usuario'] = $usuario;
        header("Location: bienvenido.php");
    }
}

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/estilos.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>
    <body>
        <form action="index.php" method="POST">
            <div class="container">
                <div class="row">
                    <div class="col">
                        Usuario:
                    </div>
                    <div class="col">
                        <input name="usuario" class="form-control"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        Clave:
                    </div>
                    <div class="col">
                        <input type="password" name="clave" class="form-control"/>
                    </div>
                </div>
                <?php if($mensaje != ""):?>
                <div class="row">
                    <div class="col alert-danger">
                       <?php echo $mensaje;?>
                    </div>
                </div>
                <?php endif;?>
                <div class="row">
                    <div class="col">
                        <button class="btn btn-success">Aceptar</button>
                    </div>
                </div>
            </div>
        </form>
    </body>
</html>
