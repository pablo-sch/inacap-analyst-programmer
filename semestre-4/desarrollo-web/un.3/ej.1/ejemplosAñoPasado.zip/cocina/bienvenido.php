<?php
include_once 'bd/Usuario.php';
session_start();

$estaConectado = false;
if(isset($_SESSION['usuario'])){
    $usuario = $_SESSION['usuario'];
    if($usuario == null){
        $estaConectado = false;
    }
    else{
        $estaConectado = true;
    }
}
if($estaConectado == false){
    header("Location: error.php");
}

?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/estilos.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>
    <body>
        <form action="index.php" method="POST">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <?php
                        echo "Bienvenido ".$usuario->nombre." tu rol es ".$usuario->rol;
                        ?>
                    </div>
                </div>
                <div class="row">
                    <a href="cerrar.php">
                        <div class="btn btn-info">Cerrar Sesión</div>
                    </a>
                </div>
            </div>
        </form>
    </body>
</html>
