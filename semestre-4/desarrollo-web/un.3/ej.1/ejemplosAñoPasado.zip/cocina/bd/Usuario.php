<?php
class Usuario{
    public $nombre;
    public $clave;
    public $rol;
}

