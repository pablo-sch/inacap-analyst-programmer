<?php

include_once 'Conexion.php';
include_once 'Usuario.php';

class UsuarioBD extends Conexion {

    //devuelve null si no coinciden los valores
    //de lo contrario devuelve el usuario correspondiente
    function login($nombreusuario,$clave){
        $devolver = null;
        $this->conectar();
        $sql = "SELECT * from usuario where nombre = ? and clave = ?";
        $stmt = $this->miConexion->prepare($sql);
        $stmt->bind_param("si", $nombreusuario,$clave);
        $stmt->execute();
        $resultados = $stmt->get_result();
        while ($fila = $resultados->fetch_assoc()) {
            $usuario = new Usuario();
            $usuario->nombre = $fila['nombre'];
            $usuario->clave = $fila['clave'];
            $usuario->rol = $fila['rol'];
            $devolver = $usuario;
        }
        $this->desconectar();
        return $devolver;
    }
    
    //hagamos el CRUD
    //1. CREAR
    function crear($usuario) {

        //necesitamos el comando insert
        //primero abrimos la conexión con el servidor de MySQL
        $this->conectar();
        //luego que está abierta la conexión, podemos enviar comandos SQL

        $sql = "INSERT INTO usuario (nombre, clave, rol)
                VALUES (?,?,?)";

        $stmt = $this->miConexion->prepare($sql);
        $stmt->bind_param("sis", $usuario->nombre, $usuario->clave, $usuario->rol);
        $ok = $stmt->execute();

        //finalmente nos desconectamos para liberar la conexión
        $this->desconectar();


        return $ok;
    }

    //2. LEER 
    function listar() {

        $arreglo = array();
        //necesitamos el comando select
        //primero abrimos la conexión con el servidor de MySQL
        $this->conectar();
        //luego que está abierta la conexión, podemos enviar comandos SQL

        $sql = "SELECT * from usuario";
        $resultados = $this->miConexion->query($sql);
        while ($fila = $resultados->fetch_assoc()) {
            $usuario = new Usuario();
            $usuario->nombre = $fila['nombre'];
            $usuario->clave = $fila['clave'];
            $usuario->rol = $fila['rol'];

            //una vez que rescatamos los datos de la fila
            //agregamos el usuario al arreglo de salida
            $arreglo[] = $usuario;
        }
        //finalmente nos desconectamos para liberar la conexión
        $this->desconectar();

        return $arreglo;
    }

    function buscar($nombre) {

        $devolver = null;
        //necesitamos el comando select
        //primero abrimos la conexión con el servidor de MySQL
        $this->conectar();
        //luego que está abierta la conexión, podemos enviar comandos SQL

        $sql = "SELECT * from usuario where nombre = ?";
        $stmt = $this->miConexion->prepare($sql);
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $resultados = $stmt->get_result();
        while ($fila = $resultados->fetch_assoc()) {
            $usuario = new Usuario();
            $usuario->nombre = $fila['nombre'];
            $usuario->clave = $fila['clave'];
            $usuario->rol = $fila['rol'];
            $devolver = $usuario;
        }
        //finalmente nos desconectamos para liberar la conexión
        $this->desconectar();

        return $devolver;
    }
    
    //3. Editar
    function editar($usuario) {

        //necesitamos el comando update
        //primero abrimos la conexión con el servidor de MySQL
        $this->conectar();
        //luego que está abierta la conexión, podemos enviar comandos SQL

        $sql = "UPDATE usuario set 
                clave = ?, rol = ? where nombre = ?";

        $stmt = $this->miConexion->prepare($sql);
        $stmt->bind_param("iss", $usuario->clave, $usuario->rol, $usuario->nombre);
        $ok = $stmt->execute();

        //finalmente nos desconectamos para liberar la conexión
        $this->desconectar();

        return $ok;
    }
    
    //4. Eliminar
    function eliminar($nombre) {

        //necesitamos el comando delete
        //primero abrimos la conexión con el servidor de MySQL
        $this->conectar();
        //luego que está abierta la conexión, podemos enviar comandos SQL

        $sql = "DELETE from usuario where nombre = ?";

        $stmt = $this->miConexion->prepare($sql);
        $stmt->bind_param("s", $nombre);
        $ok = $stmt->execute();

        //finalmente nos desconectamos para liberar la conexión
        $this->desconectar();

        return $ok;
    }
}
