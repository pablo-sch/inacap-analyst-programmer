<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/estilos.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>
    <body>
        <form action="respuesta.php" method="POST">
            <div class="row">
                <div class="col">Nombre:</div>
                <div class="col"><input class="form-control" name="nombre" /></div>
            </div>
            <div class="row">
                <div class="col">Apellido:</div>
                <div class="col"><input class="form-control" name="apellido" /></div>
            </div>
            <div class="row">
                <div class="col">
                    <button id="aceptar" class="btn btn-success">Aceptar</button>
                </div>
            </div>
        </form>
    </body>
    <script>
        $(document).ready(function(e){
            $('#aceptar').click(function(e){
                //validar 
                return false;
            });
        });
    </script>
</html>
