<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilo.css"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <title></title>
    </head>
    <body>
        <form action="index.php" method="post">
            <div class="container">
                <div class="row">
                    <div class="col">N imágenes:</div>
                    <div class="col"><input id="cantidad" class="form-control" name="cantidad"/></div>
                    <div class="textError" id="errorCantidad"></div>
                    <div class="col">
                        <button id="cargar" class="btn btn-success">Cargar</button>
                    </div>
                </div>
                <div class='row'>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/1.jpeg'/></div>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/2.jpeg'/></div>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/3.jpeg'/></div>
                </div>
                <div class='row'>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/4.jpeg'/></div>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/5.jpeg'/></div>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/6.jpeg'/></div>
                </div>
                <div class='row'>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/7.jpeg'/></div>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/8.jpeg'/></div>
                    <div class='col'><img class='image img-thumbnail' src='imagenes/9.jpeg'/></div>
                </div>
            </div>
        </form>
    </body>
    <script>
    $(document).ready(function(e){
        $('#cargar').click(function(e){
            var valido = validar();
            if(valido){
                return true;
            }
            else{
                return false;
            }
        });
        function validar(){
            var cantidad = $('#cantidad').val();
            if(isNaN(cantidad)){
                $("#errorCantidad").html("DEBE SER UN NÚMERO");
                $('#cantidad').addClass('error');
                $('#cantidad').removeClass('exito');
                return false;
            }
            else{
                if(cantidad < 1 || cantidad > 9){
                    $("#errorCantidad").html("DEBEN SER ENTRE 1 Y 9 IMÁGENES");
                    $('#cantidad').addClass('error');
                    $('#cantidad').removeClass('exito');
                    return false;
                }
            }
            $("#errorCantidad").html("");
            $('#cantidad').addClass('exito');
            $('#cantidad').removeClass('error');
            return true;
        }
    });
    </script>
</html>
