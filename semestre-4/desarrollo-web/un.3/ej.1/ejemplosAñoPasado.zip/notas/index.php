<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilos.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>
    <body>
        <div class="container">
            <form action="resultados.php" method="post">
                <div class="row">
                    <div class="col">
                        Nombre:
                    </div>
                    <div class="col">
                        <input id="nombre" class="form-control"/>
                    </div>
                    <div class="col">
                        Nota:
                    </div>
                    <div class="col">
                        <input id="nota" class="form-control"/>
                    </div>
                    <div class="col">
                        <div id="agregar" class="btn btn-success">AGREGAR</div>
                    </div>
                </div>
                <div class="row">
                    <table class="table table-stripped table-hover">
                        <thead>
                            <tr>
                                <th>
                                    Alumno
                                </th>
                                <th>
                                    Nota
                                </th>
                            </tr>
                        </thead>
                        <tbody id="alumnos">
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col">
                        <button class="btn btn-success">CALCULAR</button>
                    </div>
                </div>
            </form>
        </div>
        <script>
        $(document).ready(function(e){
            $("#agregar").click(function(e){
                var validoNombre = validarNombre();
                var validoNota = validarNota();

                if(validoNombre && validoNota){
                    var nombre = $('#nombre').val();
                    var nota = $('#nota').val();
                    var fila =  "<tr>"+
                                    "<td><input name='alumnos[]' value='"+nombre+"' class='form-control'/></td>"+
                                    "<td><input name='notas[]' value='"+nota+"' class='form-control'/></td>"+
                                "</tr>";
                    $('#alumnos').append(fila);
                    $('#nombre').val("");
                    $('#nota').val("");
               }
               return false;    
            });
            
            $('#nombre').focusout(function(e){
                validarNombre();
            });
            $('#nota').focusout(function(e){
                validarNota();
            });
            
            function validarNombre(){
                var nombre = $('#nombre').val();
                if(nombre.length < 3){
                    $('#nombre').addClass('error');
                    $('#nombre').removeClass('exito');
                    return false;
                }
                else{
                    $('#nombre').addClass('exito');
                    $('#nombre').removeClass('error');
                    return true;
                }
            }
            function validarNota(){
                var nota = $('#nota').val();
                if(isNaN(nota)){
                    $('#nota').addClass('error');
                    $('#nota').removeClass('exito');
                    return false;
                }
                else{
                    if(nota < 10 || nota > 70){
                        $('#nota').addClass('error');
                        $('#nota').removeClass('exito');
                        return false;
                    }
                    else{
                        $('#nota').addClass('exito');
                        $('#nota').removeClass('error');
                        return true;
                    }
                }
            }
        });
        </script>
    </body>
</html>
