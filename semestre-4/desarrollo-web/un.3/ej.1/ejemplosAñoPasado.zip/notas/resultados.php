<?php
$alumnos = "";
if(isset($_POST['alumnos'])){
    $alumnos = $_POST['alumnos'];
}

$notas = "";
if(isset($_POST['notas'])){
    $notas = $_POST['notas'];
}

$promedio = 0;
$masalta = 0;
$aprobados = "";
$reprobados = "";
$alumnomasalto = "";

$suma = 0;
for($i=0;$i<count($alumnos);$i++){
    $suma = $suma + $notas[$i];
    if($notas[$i] > $masalta){
        $masalta = $notas[$i];
        $alumnomasalto = $alumnos[$i];
    }
}
$promedio = number_format($suma / count($notas), 0);
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilos.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1>Resultado de Notas:</h1>
                </div>
            </div>
            <div class="row">
                <table class="table table-stripped table-hover">
                    <thead>
                        <tr>
                            <th>
                                Alumno
                            </th>
                            <th>
                                Nota
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Alumnos y notas -->   
                        <?php
                        for($i=0;$i<count($alumnos);$i++){
                            echo "<tr>";
                            echo "  <td>".$alumnos[$i]."</td><td>".$notas[$i]."</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col">
                    <h3>Promedio:</h3>
                </div>
                <div class="col">
                    <!-- promedio -->
                    <h3><?php echo $promedio; ?></h3>
                </div>
                <div class="col">
                    <h3>Nota más alta:</h3>
                </div>
                <div class="col">
                    <!-- nota más alta -->
                    <h3><?php echo $alumnomasalto.", ".$masalta; ?></h3>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <h1 class="aprobados">Aprobados:</h1>
                </div>
            </div>
            <div class="row">
                <table class="table table-stripped table-hover">
                    <thead>
                        <tr>
                            <th>
                                Alumno
                            </th>
                            <th>
                                Nota
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- aprobados -->
                        <?php
                        for($i=0;$i<count($alumnos);$i++){
                            if($notas[$i] >= 40){
                                echo "<tr class='aprobados'>";
                                echo "  <td>".$alumnos[$i]."</td><td>".$notas[$i]."</td>";
                                echo "</tr>";
                            } 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col">
                    <h1 class="reprobados">Reprobados:</h1>
                </div>
            </div>
            <div class="row">
                <table class="table table-stripped table-hover">
                    <thead>
                        <tr>
                            <th>
                                Alumno
                            </th>
                            <th>
                                Nota
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- reprobados -->
                        <?php
                        for($i=0;$i<count($alumnos);$i++){
                            if($notas[$i] < 40){
                                echo "<tr class='reprobados'>";
                                echo "  <td>".$alumnos[$i]."</td><td>".$notas[$i]."</td>";
                                echo "</tr>";
                            } 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>


