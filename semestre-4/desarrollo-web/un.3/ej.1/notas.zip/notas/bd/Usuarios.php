<?php

class Usuarios{

    public $id;
    public $nombre;
    public $apellido;
    public $clave;
    public $perfil;

}