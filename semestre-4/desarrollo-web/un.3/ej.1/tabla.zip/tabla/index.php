<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilos.css">
    </head>
    <body>
        <div class="container">
            <?php
            for($i=1;$i<=10;$i++){
                //este ciclo repetirá las filas
                echo "<div class='row'>";
                for($j=1;$j<=10;$j++){
                    //este ciclo repetirá las columnas
                    $valor = $i*$j;
                    if($valor%2 == 0){
                        echo "<div class='col verde'>$valor</div>";  
                    }
                    else{
                        echo "<div class='col amarillo'>$valor</div>"; 
                    } 
                }
                echo "</div>";
            }    
            ?>
        </div>
    </body>
</html>