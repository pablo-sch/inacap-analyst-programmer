<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilos.css">
        <script
            src="https://code.jquery.com/jquery-3.4.1.min.js"
            integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
            crossorigin="anonymous"></script>

        <script>
            $(document).ready(function(e){
                $('#boton').click(function(){
                    var numero1 = $('#txtnumero1').val();
                    var numero2 = $('#txtnumero2').val();
                    
                    var validado = true;
                    $('#errornumero1').html("");
                    $('#errornumero2').html("");
                    if(numero1 == ''){
                        $('#errornumero1').html('Error: El número 1 no puede estar vacío.');
                        validado = false;
                    }
                    if(isNaN(numero1)){
                        $('#errornumero1').html('Error: Debe ser un número.');
                        validado = false;
                    }
                    if(numero2 == ''){
                        $('#errornumero2').html('Error: El número 2 no puede estar vacío.');
                        validado = false;
                    }
                    if(isNaN(numero2)){
                        $('#errornumero2').html('Error: Debe ser un número.');
                        validado = false;
                    }
                    return validado;
                });
            });
        </script>
    </head>
    <body>
        <div class="container">
            <form action="calcular.php" method="POST">
                <div class="row">
                    <div class="col">Número 1:</div>
                    <div class="col">
                        <input id="txtnumero1" name="numero1" type="text" class="form-control">
                    </div>
                    <div class="col rojo" id="errornumero1"></div>
                </div>
                <div class="row">
                    <div class="col">Número 2:</div>
                    <div class="col">
                        <input id="txtnumero2" name="numero2" type="text" class="form-control">
                    </div>
                    <div class="col rojo" id="errornumero2"></div>
                </div>
                <div class="row">
                    <div class="col">Operación: </div>
                    <div class="col">
                        <select class="form-control" name="operacion">
                            <option value="+">SUMAR</option>
                            <option value="-">RESTAR</option>
                        </select>
                    </div>
                    <div class="col rojo" id="errornumero2"></div>
                </div>
                <div class="row">
                    <div class="col">
                        <input id="boton" type="submit" value="Calcular" class="btn btn-info">
                    </div>
                </div>
            </form>
        </div>
    </body> 
</html>