<?php

$numero1 = "";
if(isset($_POST['numero1'])){
    $numero1 = $_POST['numero1'];
}
$numero2 = "";
if(isset($_POST['numero2'])){
    $numero2 = $_POST['numero2'];
}
$operacion = "";
if(isset($_POST['operacion'])){
    $operacion = $_POST['operacion'];
}

?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <script
            src="https://code.jquery.com/jquery-3.4.1.min.js"
            integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
            crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col">
                    El resultado es <?= ($numero1 + $numero2) ?>
                </div>
            </div>
        </div>
    </body> 
</html>


