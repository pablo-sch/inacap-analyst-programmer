package com.inacap.usoclases;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
private EditText id;
private EditText nombre;
private EditText apellido;
private EditText fono;
private EditText email;
private Button primero;
private Button anterior;
private Button siguiente;
private Button ultimo;
private Button agregar;
private Button actualizar;
private Button eliminar;
private Button limpiar;
private Button buscar;
private ArrayList<Alumno> lista= new ArrayList<Alumno>();
int indice=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id = (EditText) findViewById(R.id.txtid);
        nombre = (EditText) findViewById(R.id.txtnombre);
        apellido = (EditText) findViewById(R.id.txtapellido);
        email = (EditText) findViewById(R.id.txtemail);
        fono = (EditText) findViewById(R.id.txtfono);
        buscar = (Button) findViewById(R.id.btnbuscar);
        agregar = (Button) findViewById(R.id.btnguardar);
        actualizar = (Button) findViewById(R.id.btnactualizar);
        eliminar = (Button) findViewById(R.id.btneliminar);
        limpiar = (Button) findViewById(R.id.btnlimpiar);
        primero = (Button) findViewById(R.id.btnprimero);
        siguiente = (Button) findViewById(R.id.btnsiguiente);
        anterior=(Button)findViewById(R.id.btnanterior);
        ultimo=(Button)findViewById(R.id.btnultimo);

        limpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id.setText("");
                nombre.setText("");
                apellido.setText("");
                email.setText("");
                fono.setText("");
                indice=0;
            }
        });
        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno alumno= new Alumno();
                alumno.setId(Integer.parseInt(id.getText().toString()));
                alumno.setNombre(nombre.getText().toString());
                alumno.setApellido(apellido.getText().toString());
                alumno.setEmail(email.getText().toString());
                alumno.setFono(fono.getText().toString());
                lista.add(alumno); //Añadimos un Alumno
            }
        });
        primero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno alumno=new Alumno();
                alumno= lista.get(0);
                CargarAlumno(alumno);
                indice=0;
            }
        });
        ultimo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno alumno=new Alumno();
                alumno= lista.get(lista.size()-1);
                CargarAlumno(alumno);
                indice=lista.size()-1;
            }
        });
        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(indice>=0&&indice<=lista.size()-2)
                {
                    indice++;
                    Alumno alumno=new Alumno();
                    alumno= lista.get(indice);
                    CargarAlumno(alumno);
                }else
                {
                    Toast toast= Toast.makeText(getApplicationContext(),"Error -- Fin de Lista",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
       anterior.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if(indice>0&&indice<=lista.size()-1)
               {
                   indice--;
                   Alumno alumno=new Alumno();
                   alumno= lista.get(indice);
                   CargarAlumno(alumno);
               }else
               {
                   Toast toast= Toast.makeText(getApplicationContext(),"Error -- Inicio de Lista",Toast.LENGTH_SHORT);
                   toast.show();
               }
           }
       });
    }

    public void CargarAlumno(Alumno al)
    {
        id.setText(String.valueOf(al.getId()));
        nombre.setText(al.getNombre());
        apellido.setText(al.getApellido());
        fono.setText(al.getFono());
        email.setText(al.getEmail());

    }
}
