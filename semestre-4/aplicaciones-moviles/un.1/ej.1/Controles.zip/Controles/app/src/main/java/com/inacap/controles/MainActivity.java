package com.inacap.controles;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private RadioButton si;
private RadioButton no;
private CheckBox op1;
private CheckBox op2;
private TextView seleccionado;
private Spinner opciones;
private String[] lista={"Op1", "Op2", "Op3", "Op4", "Op5"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        si=(RadioButton)findViewById(R.id.rbtSi);
        no=(RadioButton)findViewById(R.id.rbtNo);
        op1=(CheckBox)findViewById(R.id.chbOp1);
        op2=(CheckBox)findViewById(R.id.chbOp2);
        seleccionado=(TextView)findViewById(R.id.lblSeleccionado);
        opciones=(Spinner)findViewById(R.id.cmbOpciones);
        opciones.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,lista));

        si.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(si.isChecked())
                {
                    seleccionado.setText("Se Presionó Si");
                    no.setChecked(false);
                }

            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(no.isChecked())
                {
                    seleccionado.setText("Se Presionó No");
                    si.setChecked(false);
                }
            }
        });
        op1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(op1.isChecked())
                {
                    seleccionado.setText("Se Presionó Opcion 1");
                }
                else
                {
                    seleccionado.setText("");
                }
            }
        });

        op2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(op2.isChecked())
                {
                    seleccionado.setText("Se Presionó Opcion 2");
                }
                else
                {
                    seleccionado.setText("");
                }
            }
        });

        opciones.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                 seleccionado.setText((String)adapterView.getItemAtPosition(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                seleccionado.setText("");
            }
        });
    }
}
