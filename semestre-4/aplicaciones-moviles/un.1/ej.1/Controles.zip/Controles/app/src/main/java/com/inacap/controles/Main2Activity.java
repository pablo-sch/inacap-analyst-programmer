package com.inacap.controles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;


public class Main2Activity extends AppCompatActivity {
    private EditText num1;
    private EditText num2;
    private ImageView img;
    private Button ejecutar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        num1=(EditText)findViewById(R.id.txtNum1);
        num2=(EditText)findViewById(R.id.txtNum2);
        img=(ImageView)findViewById(R.id.imgGato);
        ejecutar=(Button)findViewById(R.id.btnEjecutar);

        ejecutar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(Main2Activity.this,Activity3.class);
                Bundle bundle= new Bundle();
                bundle.putInt("N1",Integer.parseInt(num1.getText().toString()));
                bundle.putInt("N2",Integer.parseInt(num2.getText().toString()));
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(Main2Activity.this,Activity3.class);
                Bundle bundle= new Bundle();
                bundle.putInt("N1",Integer.parseInt(num1.getText().toString()));
                bundle.putInt("N2",Integer.parseInt(num2.getText().toString()));
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
