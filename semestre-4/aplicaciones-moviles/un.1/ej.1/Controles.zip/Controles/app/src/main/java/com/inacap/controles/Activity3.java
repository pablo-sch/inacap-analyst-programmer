package com.inacap.controles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {
private TextView num1;
private TextView num2;
private TextView res;
int n1,n2,r;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        num1=(TextView)findViewById(R.id.lblnum1);
        num2=(TextView)findViewById(R.id.lblnum2);
        res=(TextView)findViewById(R.id.lblresultado);
        Intent intent= getIntent(); //Recibimos el Intent de la activity
        Bundle bundle= intent.getExtras(); //Recibimos el Bundle que viajo con la activity
        n1= bundle.getInt("N1");
        n2= bundle.getInt("N2");
        num1.setText(String.valueOf(n1));
        num2.setText(String.valueOf(n2));
        r=n1+n2;
        res.setText(String.valueOf(r));

    }
}
