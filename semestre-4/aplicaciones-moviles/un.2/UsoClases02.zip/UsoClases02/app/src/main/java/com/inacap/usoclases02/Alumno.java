package com.inacap.usoclases02;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Alumno implements Parcelable {
    private int id;
    private String nombre;
    private String apellido;
    private String email;
    private String fono;
    private ArrayList<Alumno> lista = new ArrayList<Alumno>();
    public Alumno()
    {

    }
    public Alumno(int id, String nombre, String apellido, String email, String fono) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.fono = fono;
    }

    public Alumno(Parcel in) {
        lista = new ArrayList<Alumno>();
        readFromParcel(in);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(nombre);
        dest.writeString(apellido);
        dest.writeString(email);
        dest.writeString(fono);
        dest.writeTypedList(lista);
    }

    private void readFromParcel(Parcel in) {
        id=in.readInt();
        nombre = in.readString();
        apellido = in.readString();
        email= in.readString();
        fono=in.readString();
        in.readTypedList(lista, CREATOR);
    }

    public static final Parcelable.Creator<Alumno> CREATOR
            = new Parcelable.Creator<Alumno>() {
        public Alumno createFromParcel(Parcel in) {
            return new Alumno(in);
        }

        public Alumno[] newArray(int size) {
            return new Alumno[size];
        }
    };
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFono() {
        return fono;
    }

    public void setFono(String fono) {
        this.fono = fono;
    }

    public void Add(Alumno alumno)
    {
        lista.add(alumno);

    }
    @Override
    public String toString()
    {
        return String.valueOf(this.nombre+" - " + this.apellido+" - "+this.email);
    }
}
