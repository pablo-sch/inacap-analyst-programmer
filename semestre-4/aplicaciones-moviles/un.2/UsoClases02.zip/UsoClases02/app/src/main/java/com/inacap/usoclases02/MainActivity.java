package com.inacap.usoclases02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
private EditText id;
private EditText nombre;
private EditText apellido;
private EditText fono;
private EditText email;
private Button agregar;
private Button actualizar;
private Button eliminar;
private Button limpiar;
private Button primero;
private Button anterior;
private Button siguiente;
private Button ultimo;
private Button buscar;
private Button listado;
ArrayList<Alumno> lista= new ArrayList<Alumno>();
int indice=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id=(EditText)findViewById(R.id.txtid);
        nombre=(EditText)findViewById(R.id.txtnombre);
        apellido=(EditText)findViewById(R.id.txtapellido);
        fono=(EditText)findViewById(R.id.txtfono);
        email=(EditText)findViewById(R.id.txtemail);
        agregar=(Button)findViewById(R.id.btnagregar);
        actualizar=(Button)findViewById(R.id.btnactualizar);
        eliminar=(Button)findViewById(R.id.btneliminar);
        limpiar=(Button)findViewById(R.id.btnlimpiar);
        buscar=(Button)findViewById(R.id.btnbuscar);
        primero=(Button)findViewById(R.id.btnprimero);
        siguiente=(Button)findViewById(R.id.btnsiguiente);
        anterior=(Button)findViewById(R.id.btnanterior);
        ultimo=(Button)findViewById(R.id.btnultimo);
        listado=(Button)findViewById(R.id.btnlistado);

        limpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id.setText("");
                nombre.setText("");
                apellido.setText("");
                email.setText("");
                fono.setText("");
                indice=0;

            }
        });
        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno al=new Alumno();
                al.setId(Integer.parseInt(id.getText().toString()));
                al.setNombre(nombre.getText().toString());
                al.setApellido(apellido.getText().toString());
                al.setEmail(email.getText().toString());
                al.setFono(fono.getText().toString());
                lista.add(al);
                Toast toast= Toast.makeText(getApplicationContext(),"Registro Agregado",Toast.LENGTH_SHORT);
                toast.show();
            }
        });
        primero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno al=new Alumno();
                al=lista.get(0);
                CargarAlumno(al);
                indice=0;
            }
        });
        ultimo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno al=new Alumno();
                al=lista.get(lista.size()-1);
                CargarAlumno(al);
                indice=lista.size()-1;
            }
        });
        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             if(indice>=0&&indice<=lista.size()-2) {
                 indice++;
                 Alumno al = new Alumno();
                 al = lista.get(indice);
                 CargarAlumno(al);
             }else
             {
                 Toast toast= Toast.makeText(getApplicationContext(),"Error - Fin de Lista",Toast.LENGTH_SHORT);
                 toast.show();
             }
            }
        });
        anterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(indice>0&&indice<=lista.size()-1) {
                    indice--;
                    Alumno al = new Alumno();
                    al = lista.get(indice);
                    CargarAlumno(al);
                }else
                {
                    Toast toast= Toast.makeText(getApplicationContext(),"Error - Inicio de Lista",Toast.LENGTH_SHORT);
                    toast.show();
                }

            }
        });
        buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Alumno al;
                boolean encontrado=false;
                int cod=Integer.parseInt(id.getText().toString());
                for(int a=0;a<lista.size() && encontrado==false;a++)
                {
                    al=new Alumno();
                    al=lista.get(a);
                    if(al.getId()==cod )
                    {
                        CargarAlumno(al);
                        encontrado=true;
                        indice=a;
                    }

                }
                if(encontrado==false)
                {
                    Toast toast= Toast.makeText(getApplicationContext(),"Id-- No Existe",Toast.LENGTH_SHORT);
                    toast.show();
                }

            }
        });
        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  if(!id.getText().equals(""))
                {
                    Alumno al= new Alumno();
                    lista.remove(indice);
                    Toast toast= Toast.makeText(getApplicationContext(),"Registro Eliminado",Toast.LENGTH_SHORT);
                    toast.show();
                    Limpiar();

                }else
                  {
                      Toast toast= Toast.makeText(getApplicationContext(),"Id-- No se Puede Eliminar",Toast.LENGTH_SHORT);
                      toast.show();
                  }
            }
        });
        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!id.getText().equals(""))
                {
                    Alumno al= new Alumno();
                    al= lista.get(indice);
                    al.setId(Integer.parseInt(id.getText().toString()));
                    al.setNombre(nombre.getText().toString());
                    al.setApellido(apellido.getText().toString());
                    al.setEmail(email.getText().toString());
                    al.setFono(fono.getText().toString());
                    lista.set(indice,al);
                    Toast toast= Toast.makeText(getApplicationContext(),"Registro Actualizado",Toast.LENGTH_SHORT);
                    toast.show();
                }else
                {
                    Toast toast= Toast.makeText(getApplicationContext(),"Id-- No se Puede Actualizar",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
        listado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Listado.class);
                Bundle bundle = new Bundle();
                intent.putExtra("Lista",lista);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });
    }
    public void CargarAlumno(Alumno al)
    {
        id.setText(String.valueOf(al.getId()));
        nombre.setText(al.getNombre());
        apellido.setText(al.getApellido());
        email.setText(al.getEmail());
        fono.setText(al.getFono());

    }
    public void Limpiar()
    {
        id.setText("");
        nombre.setText("");
        apellido.setText("");
        email.setText("");
        fono.setText("");
        indice=0;

    }
}
