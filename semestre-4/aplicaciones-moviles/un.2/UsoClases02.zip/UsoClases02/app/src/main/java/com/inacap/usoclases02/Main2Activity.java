package com.inacap.usoclases02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
private RadioButton si;
private RadioButton no;
private CheckBox op1;
private CheckBox op2;
private Spinner lista;
private TextView seleccion;
String[] li={"OP 1","OP 2", "OP 3", "OP 4", "OP 5"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        si=(RadioButton)findViewById(R.id.rbtSi);
        no=(RadioButton)findViewById(R.id.rbtNo);
        op1=(CheckBox)findViewById(R.id.chbOpcion);
        op2=(CheckBox)findViewById(R.id.chbOpcion2);
        lista=(Spinner)findViewById(R.id.cmbLista);
        seleccion=(TextView)findViewById(R.id.lblSeleccionado);

        lista.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,li));
        si.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(si.isChecked())
                {
                    seleccion.setText("Se Marcó SI");
                    no.setChecked(false);
                }
            }
        });
       no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(no.isChecked())
                {
                    seleccion.setText("Se Marcó No");
                    si.setChecked(false);
                }
            }
        });
       op1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               if(op1.isChecked())
               {
                   seleccion.setText("Se Marco OP1");
               }
               else
               {
                   seleccion.setText("");
               }
           }
       });
        op2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(op2.isChecked())
                {
                    seleccion.setText("Se Marco OP2");
                }else
                {
                    seleccion.setText("");
                }
            }
        });
        lista.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                seleccion.setText((String)adapterView.getItemAtPosition(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }



}
