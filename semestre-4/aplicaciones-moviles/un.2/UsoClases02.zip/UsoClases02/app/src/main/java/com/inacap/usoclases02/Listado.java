package com.inacap.usoclases02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class Listado extends AppCompatActivity {
    private ArrayAdapter<Alumno> adapter;
    private ArrayList<Alumno> lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listado);

        Bundle bundle = getIntent().getExtras();
        ArrayList<Alumno> lista = bundle.getParcelableArrayList("Lista");
        ConstraintLayout layout=(ConstraintLayout) findViewById(R.id.listado_activity);
        layout.setBackgroundColor(Color.DKGRAY);

        ListView lst_alumnos = (ListView)findViewById(R.id.lst_alumnos);

        adapter = new ArrayAdapter<Alumno>(getApplicationContext()
                , android.R.layout.simple_spinner_item, lista);

        lst_alumnos.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }
}
