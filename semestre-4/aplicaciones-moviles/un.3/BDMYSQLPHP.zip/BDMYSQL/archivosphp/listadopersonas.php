<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>App</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Custom Fonts -->
    <link href="../boostrap/font/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

        <div id="page-wrapper">
            <div class="row">
               <div class="col-lg-1"></diV>
                <div class="col-lg-8">
                    <h1 class="page-header">Listado de Personas</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
              <div class="col-lg-1"></diV>
                <div class="col-lg-10">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Personas
                        </div>
                        
                        
                        <!-- /.panel-heading -->
                        
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Rut</th>
                                        <th>Nombre</th>
                                        <th>Telefono</th>
                                        <th>Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                        <?php
                            

                        $enlace = mysqli_connect('localhost','mikrocom_admin','HTw[cq)k0tF?','mikrocom_appmovil');
                        if (!$enlace) {
                            echo "Error: No se pudo conectar a MySQL." . PHP_EOL;
                            echo "errno de depuracion: " . mysqli_connect_errno() . PHP_EOL;
                            echo "error de depuracion: " . mysqli_connect_error() . PHP_EOL;
                            exit;
                        }
                        else{
                                $query="select * from personas";
                                $result = $enlace->query($query);
                                $fil=0;
                                   if ($result->num_rows > 0)
                                   {
                                       // output data of each row
                                       while($row = $result->fetch_assoc())
                                       {
                                         if($fil%2==0)
                                         {
                                            echo "<tr class='odd gradeX'>";
                                            echo "<td>".$row['rut']."</td>";
                                            echo "<td>".$row['nombre']."</td>";
                                            echo "<td>".$row['telefono']."</td>";
                                            echo "<td>".$row['email']."</td>";
                                            echo "</tr>";
                                         }
                                         else
                                         {
                                            echo "<tr class='gradeU'>";
                                            echo "<td>".$row['rut']."</td>";
                                            echo "<td>".$row['nombre']."</td>";
                                            echo "<td>".$row['telefono']."</td>";
                                            echo "<td>".$row['email']."</td>";
                                            echo "</tr>";
                                             
                                         }
                                           $fil++;
                                       }
                                   }
                        }
                            
                            ?>
                      
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           <div class="col-lg-1"></diV>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
                        <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../boostrap/js/jquery-3.2.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bootstrap/js/bootstrap.min.js"></script>


    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</body>

</html>
