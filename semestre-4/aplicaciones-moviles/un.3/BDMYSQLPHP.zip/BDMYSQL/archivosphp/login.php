<?PHP
$hostname_localhost ="localhost";
$database_localhost ="mikrocom_appmovil";
$username_localhost ="mikrocom_admin";
$password_localhost ="HTw[cq)k0tF?";

$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)
or
trigger_error(mysql_error(),E_USER_ERROR);
 
mysql_select_db($database_localhost, $localhost);
$json = file_get_contents('php://input');
$obj = json_decode($json);
$user = $obj->{'user'};
$pass =md5($obj->{'pass'});
$query_search = "select * from usuarios where usuario='".$user."' and password='".$pass."'";
$query_exec = mysql_query($query_search) or die(mysql_error());
$json = array();	
	if(mysql_num_rows($query_exec)){
		while($row=mysql_fetch_assoc($query_exec)){
		$json['usuario'][]=$row;
		}
	}
	mysql_close($localhost);
	echo json_encode($json);
?>