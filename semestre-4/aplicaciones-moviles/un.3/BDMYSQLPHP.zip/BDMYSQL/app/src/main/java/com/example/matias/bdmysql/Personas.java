package com.example.matias.bdmysql;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Matias on 08-11-2017.
 */

public class Personas {

    private String nombre;
    private String rut;
    private String telefono;
    private String email;

    public Personas(){}

    public Personas(String nombre, String rut, String telefono, String email) {
        this.nombre = nombre;
        this.rut = rut;
        this.telefono = telefono;
        this.email = email;
    }

    public Personas(JSONObject objetoJSON)throws JSONException {
        nombre = objetoJSON.getString("nombre");
        rut = objetoJSON.getString("rut");
        telefono= objetoJSON.getString("telefono");
        email=objetoJSON.getString("email");
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getRut() {
        return rut;
    }
    public void setRut(String rut) {
        this.rut = rut;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
}
