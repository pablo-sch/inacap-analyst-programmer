package com.example.matias.bdmysql;


import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;


public class MainActivity extends AppCompatActivity {

    private EditText rut;
    private EditText nombre;
    private EditText telefono;
    private EditText email;
    private Button insertar;
    private Button btnmostrar;
    private Button update;
    private Button eliminar;
   // private Button login;
    private int posicion = 0;
    private List<Personas> listaPersonas;
    private Personas personas;

    @SuppressLint("InlinedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        setContentView(R.layout.activity_main);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED){

            }

        listaPersonas = new ArrayList<Personas>();
        rut = (EditText) findViewById(R.id.rut);
        nombre = (EditText) findViewById(R.id.nombre);
        telefono = (EditText) findViewById(R.id.telefono);
        email = (EditText) findViewById(R.id.email);
        insertar= (Button)findViewById(R.id.insertar);
        update=(Button)findViewById(R.id.update);
        btnmostrar=(Button)findViewById(R.id.btnmostrar);
        eliminar=(Button)findViewById(R.id.eliminar);
       // login=(Button)findViewById(R.id.btnlogin);

         /*
     Este código permite la inserción de Registros en la Base de datos
     Para verificar que nuestro código funciona
     podemos verificar en la Url
     www.mikrocom.cl/app/listadopersonas.php

   */
        insertar.setOnClickListener(new OnClickListener() {
            @Override

            public void onClick(View arg0) {
                String trut = rut.getText().toString();
                String tnombre = nombre.getText().toString();
                String tfono =telefono.getText().toString();
                String temail = email.getText().toString();
                JSONObject userJson1 = new JSONObject();
                try {
                    userJson1.put("rut", trut);
                    userJson1.put("nombre", tnombre);
                    userJson1.put("telefono", tfono);
                    userJson1.put("email", temail);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String jsonString1 = userJson1.toString();
                String url1 = "http://www.mikrocom.cl/app/createperson.php";
                try {
                    Back ejec= new Back(new Back.AsyncResponse() {
                        @Override
                        public void processFinish(String jsonResult) {
                            try {
                                if (!jsonResult.equals("-1")) {
                                    Toast.makeText(getApplicationContext(), "Persona Registrada Correctamente.", Toast.LENGTH_LONG).show();


                                } else {
                                    Toast.makeText(getApplicationContext(), "Error al Insertar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error al Insertar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                    ejec.execute(url1, jsonString1);

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Error al Insertar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();
                }
            }

    });

  /*
     Este código permite la Actualización de Registros en la Base de datos
     Para verificar que nuestro código funciona
     podemos verificar en la Url
     www.mikrocom.cl/app/listadopersonas.php

   */
        update.setOnClickListener(new OnClickListener() {
            @Override

            public void onClick(View arg0) {
                String trut = rut.getText().toString();
                String tnombre = nombre.getText().toString();
                String tfono =telefono.getText().toString();
                String temail = email.getText().toString();
                JSONObject userJson1 = new JSONObject();
                try {
                    userJson1.put("rut", trut);
                    userJson1.put("nombre", tnombre);
                    userJson1.put("telefono", tfono);
                    userJson1.put("email", temail);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String jsonString1 = userJson1.toString();
                String url1 = "http://www.mikrocom.cl/app/editperson.php";
                try {
                    Back ejec = new Back(new Back.AsyncResponse() {
                        @Override
                        public void processFinish(String jsonResult) {
                            try {
                                if (!jsonResult.equals("-1")) {
                                    Toast.makeText(getApplicationContext(), "Persona Actualizada Correctamente.", Toast.LENGTH_LONG).show();


                                } else {
                                    Toast.makeText(getApplicationContext(), "Error al Actualizar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error al Actualizar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                    ejec.execute(url1, jsonString1);

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Error al Actualizar, intente nuevamente.", Toast.LENGTH_LONG).show();
                }
            }

        });

        /*
             Este código permite la Eliminación de Registros en la Base de datos
             Para verificar que nuestro código funciona
             podemos verificar en la Url
             www.mikrocom.cl/app/listadopersonas.php

         */
        eliminar.setOnClickListener(new OnClickListener() {
            @Override

            public void onClick(View arg0) {
                String trut = rut.getText().toString();

                JSONObject userJson1 = new JSONObject();
                try {
                    userJson1.put("rut", trut);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String jsonString1 = userJson1.toString();
                String url1 = "http://www.mikrocom.cl/app/deleteperson.php";
                try {
                    Back ejec = new Back(new Back.AsyncResponse() {
                        @Override
                        public void processFinish(String jsonResult) {
                            try {
                                if (!jsonResult.equals("-1")) {
                                    Toast.makeText(getApplicationContext(), "Persona Eliminada Correctamente.", Toast.LENGTH_LONG).show();


                                } else {
                                    Toast.makeText(getApplicationContext(), "Error al Eliminar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error al Eliminar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                    ejec.execute(url1, jsonString1);

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Error al Eliminar Datos, intente nuevamente.", Toast.LENGTH_LONG).show();
                }
            }

        });

        /*
          Buscamos un Registro dentro de la Tabla
         */
       btnmostrar.setOnClickListener(new OnClickListener() {
           @Override
           public void onClick(View view) {
               JSONObject userJson = new JSONObject();
               try {
                   userJson.put("rut", rut.getText().toString());
                   //userJson.put("password", nombre.getText().toString());
               } catch (JSONException e) {
                   e.printStackTrace();
               }

               String jsonString = userJson.toString();
               String url = "http://www.mikrocom.cl/app/findperson.php";

               try {

                   Back login = new Back(new Back.AsyncResponse() {

                       @Override
                       public void processFinish(String jsonResult) {
                           try {
                               if(!jsonResult.equals("-1")){
                                   String user = rut.getText().toString();
                                   JSONObject json = new JSONObject(jsonResult);
                                   List<Personas> lista_personas = new ArrayList<>(); //inicializamos la lista donde almacenaremos los objetos Fruta

                                   JSONArray json_array = json.optJSONArray("persona"); //cogemos cada uno de los elementos dentro de la etiqueta "frutas"

                                   for (int i = 0; i < json_array.length(); i++) {
                                       lista_personas.add(new Personas(json_array.getJSONObject(i))); //creamos un objeto Fruta y lo insertamos en la lista
                                   }


                                   if(user.equals(lista_personas.get(0).getRut())) {
                                        nombre.setText(lista_personas.get(0).getNombre().toString());
                                        telefono.setText(lista_personas.get(0).getTelefono().toString());
                                        email.setText(lista_personas.get(0).getEmail().toString());
                                   }
                                   else
                                   {
                                       Toast.makeText(getApplicationContext(), "Persona no Existe", Toast.LENGTH_LONG).show();
                                   }
                               }
                               else{
                                   Toast.makeText(getApplicationContext(), "Persona no Existe", Toast.LENGTH_LONG).show();
                               }

                           } catch (Exception e) {
                               Toast.makeText(getApplicationContext(), "Error - Persona no Existe", Toast.LENGTH_LONG).show();

                           }
                       }
                   });
                   login.execute(url, jsonString);

               } catch (Exception e) {
                   Toast.makeText(getApplicationContext(), "Error - Persona no Existe", Toast.LENGTH_LONG).show();
               }




           }
       });



    }







    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 0: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {

                }
                return;
            }
        }
    }




}