package app.inacap.cl.usobd.Clases;

/**
 * Created by cesar on 12-06-17.
 */


import static android.provider.BaseColumns._ID;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class BDNotas extends  SQLiteOpenHelper {

    private final Context context;
    public static int version_db = 1;
    public BDNotas(Context context, String name, CursorFactory factory, int version)
    {
        super(context, name, factory, version);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        if(db.isReadOnly())
        {
            db = getWritableDatabase();
        }
        String  query = "CREATE TABLE notasalumnos(" +
                _ID+" INTEGER PRIMARY KEY AUTOINCREMENT," +
                "alumno TEXT,"+
                "nota1 NUMERIC,"+
                "nota2 NUMERIC,"+
                "nota3 NUMERIC,"+
                "promedio NUMERIC)";
        db.execSQL(query);
    }

    //Metodo para insertar un Cliente
    public void crearNota(NotasAlumno alumno)
    {
        ContentValues valores  = new ContentValues();
        valores.put("alumno", alumno.getAlumno());
        valores.put("nota1", alumno.getNota1());
        valores.put("nota2", alumno.getNota2());
        valores.put("nota3", alumno.getNota3());
        valores.put("promedio", alumno.getPromedio());
        long insert_id=this.getWritableDatabase().insert("notasalumno", null, valores);
        String filas[] = {_ID, "alumno","nota1", "nota2","nota3","promedio"};
        Cursor cursor= this.getWritableDatabase().query("notasalumno", filas,"_ID="+insert_id, null,null,null,null);
        cursor.moveToFirst();
        NotasAlumno nuevo= cursorToAlumnos(cursor);
        cursor.close();


    }

    public void modificarAlumno(NotasAlumno alum)
    {
        long id= alum.getId();
        ContentValues valores  = new ContentValues();
        valores.put("alumno", alum.getAlumno());
        valores.put("nota1", alum.getNota1());
        valores.put("nota2", alum.getNota2());
        valores.put("nota3", alum.getNota3());
        valores.put("promedio", alum.getPromedio());
        this.getWritableDatabase().update("notasalumnos", valores, "id =" +id,null);

    }
    public ArrayList<NotasAlumno> getAllNotas(){

        ArrayList<NotasAlumno> list= new ArrayList<NotasAlumno>();
        String filas[] = {_ID,"alumno", "nota1", "nota2","nota3","promedio"};
        Cursor c = this.getReadableDatabase().query("notasalumno", filas,null, null, null, null, null);
        c.moveToFirst();

        while(!c.isAfterLast())
        {
            NotasAlumno alum= cursorToAlumnos(c);
            list.add(alum);
            c.moveToNext();
        }
        c.close();
        return list;
    }

    //Metodo para eliminar un cliente
    public void EliminarCliente(NotasAlumno alum)
    {
        long id= alum.getId();
        this.getWritableDatabase().delete("notasalumno", "id= "+id, null);
    }

    public NotasAlumno Buscar(int id)
    {

        NotasAlumno alum=null;
        String filas[] = {_ID,"alumno", "nota1", "nota2","nota3","promedio"};

        //Cursor c = this.getReadableDatabase().query("clientes", filas,"idcliente="+idcliente,null, null, null, null);
        Cursor c = this.getReadableDatabase().rawQuery("SELECT * FROM clientes WHERE idcliente = "+id, null);
        if(c.moveToFirst())// se encontró registro
        {
            alum= cursorToAlumnos(c);
            c.close();
        }
        return alum;

    }

    private NotasAlumno cursorToAlumnos(Cursor cursor)
    {
        NotasAlumno alum= new NotasAlumno();
        alum.setAlumno(cursor.getString(1));
        alum.setNota1(cursor.getDouble(2));
        alum.setNota2(cursor.getDouble(3));
        alum.setNota3(cursor.getDouble(4));
        alum.setPromedio(cursor.getDouble(5));
        return alum;

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        if(newVersion > oldVersion)
        {
            //db.execSQL(UPDATE_DB);
        }
    }
    public void abrir(){
        this.getWritableDatabase();
    }


    public void cerrar(){
        this.close();
    }



}
