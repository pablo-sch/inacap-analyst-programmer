/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author cesar
 */
import modelo.Conexion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AccesoClientes extends Conexion{
    private int rut;
    private String nombres;
    private String apaterno;
    private String amaterno;
    private String direccion;
    private int fono;
    private String email;
    private String sexo;
    ResultSet resultado;
    
    public AccesoClientes()
    {
       Conectar();
    }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApaterno() {
        return apaterno;
    }

    public void setApaterno(String apaterno) {
        this.apaterno = apaterno;
    }

    public String getAmaterno() {
        return amaterno;
    }

    public void setAmaterno(String amaterno) {
        this.amaterno = amaterno;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getFono() {
        return fono;
    }

    public void setFono(int fono) {
        this.fono = fono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
     public void Insertar(int rut,String nombres,String apaterno,String amaterno,int fono,String
             direccion, String email,String sexo) throws Exception
    {
           try{
             getStmt();
	     stmt.executeUpdate("INSERT INTO CLIENTE values("+rut+",'"+nombres+"','"+apaterno+
                     
                     "','"+amaterno+"','"+direccion+"',"+fono+",'"+email+"','"+sexo+"')");
        }catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
        }
    }
     
      public ResultSet Listado()throws Exception
    {
        try{
            getStmt();
	     resultado= stmt.executeQuery("SELECT * FROM CLIENTE");
             return resultado;
             }catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
           return null;
        }
    }
    public void Actualizar(int rut,String nombres,String apaterno,String amaterno,int fono,String
             direccion, String email,String sexo) throws Exception
    {
           try{
             getStmt();
	     stmt.executeUpdate("UPDATE CLIENTE SET CLINOMBRES='"+nombres +"',CLIAPATERNO='"+apaterno+
                     "',CLIAMATERNO='"+amaterno +"',CLIFONO="+fono+",CLIDIRECCION='"+direccion+
                     "',CLIEMAIL='"+email+"',CLISEXO='"+sexo+"' WHERE CLIRUT="+rut);
        }catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
        }
    }
      
      public void Eliminar(int rut)throws Exception
    {
         try{
             getStmt();
	     stmt.executeUpdate("DELETE FROM CLIENTE WHERE CLIRUT=" + rut );
        } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
        }
    }
    
    
}
