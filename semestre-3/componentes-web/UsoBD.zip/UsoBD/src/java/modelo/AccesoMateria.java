/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo;

import modelo.Conexion;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AccesoMateria extends Conexion {
    private int MatCodigo;

    public int getMatCodigo() {
        return MatCodigo;
    }

    public void setMatCodigo(int MatCodigo) {
        this.MatCodigo = MatCodigo;
    }

    public String getMatNombre() {
        return MatNombre;
    }

    public void setMatNombre(String MatNombre) {
        this.MatNombre = MatNombre;
    }
    private String MatNombre;
  
    private ResultSet resultado;

    public AccesoMateria()
    {
        Conectar();
    }

    public AccesoMateria(int MatCodigo, String MatNombre) {
        this.MatCodigo = MatCodigo;
        this.MatNombre = MatNombre;
    }
   

    public ResultSet Listado()throws Exception
    {
        try{
            getStmt();
	     resultado= stmt.executeQuery("SELECT * FROM MATERIAS");
             return resultado;
             }catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
           return null;
        }
    }

    public void Insertar(int MatCodigo,String MatNombre) throws Exception
    {
           try{
             getStmt();
	     stmt.executeUpdate("INSERT INTO MATERIAS values (" + MatCodigo + ", '" + MatNombre +"')");
        }catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
        }
    }
    
    public void Actualizar(int MatCodigo,String MatNombre)throws Exception
    {
        try{
             getStmt();
	     stmt.executeUpdate("UPDATE MATERIAS SET MATNOMBRE= '" + MatNombre+ "' WHERE MATCODIGO=" + MatCodigo );
        } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
        }
    }
    public void Eliminar(int MatCodigo)throws Exception
    {
         try{
             getStmt();
	     stmt.executeUpdate("DELETE FROM MATERIAS WHERE MATCODIGO=" + MatCodigo );
        } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
        }
    }
    public ResultSet BuscarExistente(int MatCodigo) throws Exception
    {   try{
             getStmt();
	     resultado= stmt.executeQuery("SELECT * FROM MATERIAS WHERE MATCODIGO LIKE'" + MatCodigo+"%'");
               return resultado;
             } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
           return null;
        }
    }

    public ResultSet BuscarPorNombre(String MatNombre) throws Exception
    {
        try{
       
             getStmt();
	     resultado= stmt.executeQuery("SELECT * FROM MATERIAS WHERE (MATNOMBRE LIKE '" + MatNombre + "%')");
             return resultado;
              } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
           return null;
           }
    }
    public ResultSet BuscarNombre(String MatNombre) throws Exception
    {
        try{

             getStmt();
	     resultado= stmt.executeQuery("SELECT * FROM MATERIAS WHERE (MATNOMBRE ='" + MatNombre + "')");
             return resultado;
              } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
           return null;
           }
    }
    public ResultSet BuscarTodo(int MatCodigo,String MatNombre) throws Exception
    {
        try{

             getStmt();
	     resultado= stmt.executeQuery("SELECT * FROM MATERIAS WHERE (MATCODIGO like '"+MatCodigo+ "%' and MATNOMBRE like'" + MatNombre + "%')");
             return resultado;
              } catch (Exception ex){
           System.err.println("SQLException: " + ex.getMessage());
           return null;
           }
    }

}
