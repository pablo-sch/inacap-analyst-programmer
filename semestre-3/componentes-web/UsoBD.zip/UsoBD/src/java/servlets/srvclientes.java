/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.AccesoClientes;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cesar
 */
public class srvclientes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
         response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            AccesoClientes cliente=new AccesoClientes();
            ResultSet resultado;
            //Recibimos los parámetros de la pagina
            int rut=0;
            String nombres="";
            String apaterno="";
            String amaterno="";
            String direccion="";
            int fono=0;
            String email="";
            String rbtsexo=request.getParameter("sexo");
            String sexo="";
            String boton=request.getParameter("btnenviar");
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet srvclientes</title>");  
            out.println("<link rel='stylesheet' href='css/bootstrap.min.css'>");
            out.println("</head>");
            out.println("<body>");
            //Evaluamos las opciones
            if(boton.equals("Agregar"))
            {
                rut=Integer.parseInt(request.getParameter("txtrut"));
                nombres=request.getParameter("txtnombres");
                apaterno=request.getParameter("txtapaterno");
                amaterno=request.getParameter("txtamaterno");
                direccion=request.getParameter("txtdireccion");
                fono=Integer.parseInt(request.getParameter("txtfono"));
                email=request.getParameter("txtemail");
                if(rbtsexo.equals("M"))
                {
                   sexo="M";
                }
                if(rbtsexo.equals("F"))
                {
                  sexo="F";
                }
                try {
                    cliente.Insertar(rut,nombres,apaterno,amaterno,fono,direccion,email,sexo);
                                       
                    resultado=cliente.Listado();
                    Mostrar(resultado,response);
                    
                } catch (Exception ex) {
                    Logger.getLogger(srvclientes.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(boton.equals("Actualizar"))
            {
                    rut=Integer.parseInt(request.getParameter("txtrut"));
                nombres=request.getParameter("txtnombres");
                apaterno=request.getParameter("txtapaterno");
                amaterno=request.getParameter("txtamaterno");
                direccion=request.getParameter("txtdireccion");
                fono=Integer.parseInt(request.getParameter("txtfono"));
                email=request.getParameter("txtemail");
                if(rbtsexo.equals("M"))
                {
                   sexo="M";
                }
                if(rbtsexo.equals("F"))
                {
                  sexo="F";
                }
                try {
                    cliente.Actualizar(rut,nombres,apaterno,amaterno,fono,direccion,email,sexo);
                                       
                    resultado=cliente.Listado();
                    Mostrar(resultado,response);
                    
                } catch (Exception ex) {
                    Logger.getLogger(srvclientes.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(boton.equals("Listado"))
            {
               try{
                    resultado=cliente.Listado();
                    Mostrar(resultado,response);
               }
               catch(Exception ex)
               {
                    Logger.getLogger(srvclientes.class.getName()).log(Level.SEVERE, null, ex);
               }
            }
            if(boton.equals("Eliminar"))
            {
                     rut=Integer.parseInt(request.getParameter("txtrut"));
                    try{
                    cliente.Eliminar(rut);
                    resultado=cliente.Listado();
                    Mostrar(resultado,response);
               }
               catch(Exception ex)
               {
                    Logger.getLogger(srvclientes.class.getName()).log(Level.SEVERE, null, ex);
               }     
            }
        }
    }

    public void Mostrar(ResultSet resultado,HttpServletResponse response) throws IOException
    {
        PrintWriter out = response.getWriter();
        int rut=0;
            String nombres="";
            String apaterno="";
            String amaterno="";
            String direccion="";
            int fono=0;
            String email="";
            String sexo="";
        out.println("<div class='row'>");
        out.println("<div class='col-md-1'></div>");
        out.println("<div class='col-md-9'>");
        out.println("<table class='table'>");
        out.println("<tr><th scope='col'>Rut</th><th scope='col'>Nombres</th><th scope='col'>A.Paterno</th><th scope='col'>A.Materno</th><th scope='col'>Direccion</th><th scope='col'>Fono</th><th scope='col'>Email</th><th scope='col'>Sexo</th>"
                + "</tr>");
                
                try {
                    
                    while(resultado.next())
                    {
                        rut=resultado.getInt("CLIRUT");
                        nombres=resultado.getString("CLINOMBRES");
                        apaterno=resultado.getString("CLIAPATERNO");
                        amaterno=resultado.getString("CLIAMATERNO");
                        direccion=resultado.getString("CLIDIRECCION");
                        fono=resultado.getInt("CLIFONO");
                        email=resultado.getString("CLIEMAIL");
                        if(resultado.getString("CLISEXO").equals("M"))
                        {
                           sexo="Masculino";
                        }else
                        {
                          sexo="Femenino";
                        }
                        
                        
                        out.println("<tr scope='row'>");
                        out.println("<td>"+rut+"</td>");
                        out.println("<td>"+nombres+"</td>");
                        out.println("<td>"+apaterno+"</td>");
                        out.println("<td>"+amaterno+"</td>");
                        out.println("<td>"+direccion+"</td>");
                        out.println("<td>"+fono+"</td>");
                        out.println("<td>"+email+"</td>");
                        out.println("<td>"+sexo+"</td>");
                        out.println("</tr>");
                    }
                    out.println("</table>");
                    out.println("</div>"); //Cerramos col-md-8
                    out.println("</div>"); //Cerramos row
                } catch (Exception ex) {
                    Logger.getLogger(srvclientes.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
